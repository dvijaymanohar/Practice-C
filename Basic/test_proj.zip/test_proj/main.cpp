#include <cstdlib>
#include <iostream>

#include "test_func.h"
using namespace std;

int main(int argc, char *argv[])
{
    i =10;
    j = 11;
    other();
    
    system("PAUSE");
    return EXIT_SUCCESS;
}


