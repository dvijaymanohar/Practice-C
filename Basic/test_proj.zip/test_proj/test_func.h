
#ifndef __TEST_FUNC_H__
#define __TEST_FUNC_H__

extern int i;
extern int j;

extern void other (void);

#endif
